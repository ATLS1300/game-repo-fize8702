#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 9 2020
Finished on Wed Oct 14 2020

@author: Dr. Z 
@author: Fidan

"""

""" This is a very simple interactive puzzle 
for people who use games in order to relax,
by not having to logically think 
but just use visual precision to navigate through the game.

In order to make this game a little challenging,
I only used two shades of a same color
to trick the player visually,
as well as I made a very dense cluster of small squares
to make it easy to click on a wrong color

The whole purpose of this particular game is
to get rid of dark shade of the colors 
and avoid the lighter shade, at all costs.

This whole process of repetitive cleansing of darkness
can also connect to a therapeutic association of 
“detoxing from dark memories, events, thoughts” and many more, 
in order to keep the lightness in each player's life.

The goal is to reach to a point where no dark red squares are left


To navigate through this game you should:
    
    Wait untill all the squares fill up the screen
    
    Only click with your mouse on the dark red squares
    
    Clicking the light red square will end the game

"""


import turtle, random, time # imported libraries to use in my code

# Screen dimensions 
w=800
h=800
turtle.setup(w,h) # start with calling setup to turn on listeners
turtle.listen() # for keyboard listening


# Setting up my screen
panel=turtle.Screen()
running = True  # for controlling the while loop
numTurt = 200 # number of my initial turtles

turtleWidth = 20 # size of each square

passColor = 'red4' # dark red squares that need to be cleaned while playing
failColor = 'red2' # light red squares that should be avoided to be touched

COLORS = [passColor, failColor] # listr of my colors for the game

bgcolor = 'black' # my background color
panel.bgcolor(bgcolor) # if image doesn't work this code links to bgcolor variable name

# Comented out codes below is provided for an ideal experience for the game
# I just can't figure out why my squares doesn't show up on top of it
# Background image
# image = "detoxbg.gif"
# panel.bgpic(image)

gameOver = turtle.Turtle() # my turtle to end the game

# Helps to execute each drawing fast and at the same time
turtle.tracer(0)

# Created an empty list in order to add to this list in a for loop, using list functions
turtList = []

for i in range(numTurt):
   turtList.append(turtle.Turtle()) # append adds a turtle to the end of the list

def delTurt(x,y):
    # Codes below was adviced by my brother to help me find the squares to erase
    # Garbbing the global variable from variable named running
    global running
    
    # To check if the game is still running
    if running:
        
        # for loop below to find the turtle that is clicked
        for i in range(numTurt):
            findTurt = turtList[i]
            xt = findTurt.xcor()
            yt = findTurt.ycor()
            
            # to check if the mouse click is in inside the drawn square
            if((x <= xt and x >= xt-turtleWidth)
               and (y >= yt and y <= yt+turtleWidth)):
                
                # To check if the clicked square matches with the pass color
                if(findTurt.fillcolor() == passColor):
                    
                    # To erase the turtle back to black
                    findTurt.color(bgcolor)
                    findTurt.begin_fill()
                    
                    # for loop to draw the square
                    for k in range(4):
                        findTurt.left(90)
                        findTurt.forward(turtleWidth)
                    findTurt.hideturtle()
                    findTurt.end_fill()
                    
                    # To create a new turtle randomly
                    color = random.choice(COLORS) # squares draw colors randomy this way
                    findTurt.color(color) # how would this line change if I want each turtle to be a diff color?
                    # findTurt.speed(speed)
                    findTurt.up()
                    findTurt.goto(random.randint(-200,200),random.randint(-200,200))
                    findTurt.down()
                    findTurt.begin_fill()
                    for k in range(4):
                        findTurt.left(90)
                        findTurt.forward(turtleWidth)
                    findTurt.end_fill()
                
                # The game ends when clicked wrong turtle
                else:
                    running = False
                    panel.reset()
                    
                    # Game over text to end the game
                    # Helped and provided by Dr. Z
                    gameOver = turtle.Turtle()
                    gameOver.color('red')
                    style = ('Helvetica', 80, 'bold')
                    gameOver.up()
                    gameOver.hideturtle()
                    gameOver.goto(0,0)
                    
                    # gameover condition
                    gameOver.write('GAMEOVER!', font=style, align='center')

# Regenerates a new square after each time a square gets erased 
for i in range(len(turtList)):
    color = random.choice(COLORS)
    turtList[i].color(color) 
    turtList[i].up()
    turtList[i].goto(random.randint(-200,200),random.randint(-200,200))
    turtList[i].down()
    turtList[i].begin_fill()
    for k in range(4):
        turtList[i].left(90)
        turtList[i].forward(turtleWidth)
    turtList[i].end_fill()
    panel.update()

panel.onscreenclick(delTurt) # activates the click function

# this while loop allows the animation to kick in
while running:
    
    time.sleep(0.33) # lets the squares appear in a certain timeframe

    panel.update() # updates each appearance of the square one by one

panel.mainloop() 
turtle.done() 

""" I let my sister play this game and she mentioned that this game feels like a
baby of Minesweeper and Whac-A-Mole :D And she said it would have been a better experience
if she could restart the game in order to reach the goal """
